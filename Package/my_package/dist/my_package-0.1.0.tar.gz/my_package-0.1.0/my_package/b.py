class B:
    def function_b(self):
        return "Function B from Class B"
