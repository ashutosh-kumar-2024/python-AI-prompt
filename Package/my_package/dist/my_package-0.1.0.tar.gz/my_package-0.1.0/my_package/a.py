class A:
    def function_a(self):
        return "Function A from Class A"
